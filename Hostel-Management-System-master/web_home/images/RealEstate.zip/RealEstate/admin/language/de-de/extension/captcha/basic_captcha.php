<?php
$_['heading_title']    = 'Basis Captcha';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']	   = 'Succes: je hebt Basic Captcha aangepast!';
$_['text_edit']        = 'Bewerk de basis Captcha';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: je hebt geen toestemming om Basic Captcha te wijzigen!';
