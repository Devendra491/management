<?php
// Heading
$_['heading_title']    = 'Categorieën';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de dashboardklant aangepast!';
$_['text_edit']        = 'Bewerk Dashboard-klant';
$_['text_view']        = 'Bekijk meer...';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de dashboardklant te wijzigen!';