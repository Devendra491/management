<?php
// Heading
$_['heading_title']    = 'Belastingen';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft het totale belastingtarief gewijzigd!';
$_['text_edit']        = 'Bewerk belasting totaal';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om het belastingentotaal te wijzigen!';