<?php
// Heading
$_['heading_title']    = 'Sub-Total';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft het totale subtotaal gewijzigd!';
$_['text_edit']        = 'Bewerk subtotaal totaal';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om het subtotaal totaal te wijzigen!';