<?php
// Heading
$_['heading_title'] = 'Totale galerij';

// Text
$_['text_view']     = 'Bekijk meer...';