<?php
// Heading
$_['heading_title']    = 'Thema's';

// Text
$_['text_success']     = 'Succes: je hebt aangepaste thema's!';
$_['text_list']        = 'Themalijst';

// Column
$_['column_name']      = 'Theme Name';
$_['column_status']    = 'staat';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om thema's aan te passen!';