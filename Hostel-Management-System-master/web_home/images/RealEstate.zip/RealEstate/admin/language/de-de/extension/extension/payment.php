<?php
// Heading
$_['heading_title']     = 'betalingen';

// Text
$_['text_success']      = 'Succes: u heeft de betalingen gewijzigd!';
$_['text_list']         = 'Betalingslijst';

// Column
$_['column_name']       = 'Betalingsmiddel';
$_['column_status']     = 'staat';
$_['column_sort_order'] = 'sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Waarschuwing: u bent niet gemachtigd om betalingen te wijzigen!';