<?php
// Heading
$_['heading_title']    = 'Coupon';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft het totale bedrag van de coupon gewijzigd!';
$_['text_edit']        = 'Coupon bewerken';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om het kortingsbon-totaal te wijzigen!';