<?php
// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de accountmodule aangepast!';
$_['text_edit']        = 'Bewerk de accountmodule';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de accountmodule te wijzigen!';