<?php
// Heading
$_['heading_title']     = 'Verzenden';

// Text
$_['text_success']      = 'Succes: je hebt de verzending aangepast!';
$_['text_list']         = 'Verzendlijst';

// Column
$_['column_name']       = 'Verzendmethode';
$_['column_status']     = 'staat';
$_['column_sort_order'] = 'sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Waarschuwing: u bent niet gemachtigd om verzending te wijzigen!';