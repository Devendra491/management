<?php
// Heading
$_['heading_title']    = 'Categorie';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de categoriemodule aangepast!';
$_['text_edit']        = 'Bewerk categoriemodule';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de categoriemodule te wijzigen!';