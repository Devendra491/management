<?php
// Heading
$_['heading_title']    = 'Geschenkbon';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft het totale cadeaubon totaal gewijzigd!';
$_['text_edit']        = 'Bewerk cadeaubon totaal';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om het totale cadeaubon te wijzigen!';