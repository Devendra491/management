<?php
$_['text_dash']                     = 'Dashboard';
$_['text_gallery']                  = 'Galerij';
$_['text_photo']                    = 'Foto';
$_['text_sett']                     = 'instellingen';
$_['text_addmodule']                = 'Module toevoegen';
$_['text_about']                    = 'Over ons';
