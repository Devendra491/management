<?php
// Heading
$_['heading_title']  = 'Pagina niet gevonden!';

// Text
$_['text_not_found'] = 'De pagina waarnaar u op zoek was, kon niet gevonden worden! Neem contact op met uw beheerder als het probleem aanhoudt.';