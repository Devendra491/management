<?php
// Heading
$_['heading_title']    = 'Totale verkoop';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u hebt de dashboardverkoop aangepast!';
$_['text_edit']        = 'Dashboardverkoop bewerken';
$_['text_view']        = 'Bekijk meer...';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'StatusSort Order';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om dashboardverkoop te wijzigen!';