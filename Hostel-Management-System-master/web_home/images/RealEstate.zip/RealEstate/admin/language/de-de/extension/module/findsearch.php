<?php
// Heading
$_['heading_title']    = 'Zoek zoeken';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de module Zoeken zoeken gewijzigd!';
$_['text_edit']        = 'Edit Find Search Module';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de module Zoeken doorzoeken te wijzigen!';