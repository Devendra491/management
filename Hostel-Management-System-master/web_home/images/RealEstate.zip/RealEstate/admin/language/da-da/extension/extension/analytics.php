<?php
// Heading
$_['heading_title']    = 'Analytics';

// Text
$_['text_success']     = 'Succes: Du har ændret analyser!';
$_['text_list']        = 'Analytics liste';

// Column
$_['column_name']      = 'Analytics navn';
$_['column_status']    = 'status';
$_['column_action']    = 'Handling';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre analyser!';