<?php
// Heading
$_['heading_title']      = 'Om os';
?>
