<?php
// Heading
$_['heading_title'] = '<b>I alt BlogCategories</b>';

// Text
$_['text_view']     = 'Se mere...';