<?php
$_['text_dash']                     = 'instrumentbræt';
$_['text_gallery']                  = 'Galleri';
$_['text_photo']                    = 'Foto';
$_['text_sett']                     = 'Indstillinger';
$_['text_addmodule']                = 'Tilføj modul';
$_['text_about']                    = 'Om os';
