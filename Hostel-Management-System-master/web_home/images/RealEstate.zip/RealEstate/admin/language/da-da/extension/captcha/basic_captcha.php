<?php
$_['heading_title']    = 'Grundlæggende Captcha';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']	   = 'Succes: Du har ændret Basic Captcha!';
$_['text_edit']        = 'Rediger Basic Captcha';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Basic Captcha!';
