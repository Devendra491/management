<?php
// Heading
$_['heading_title'] = 'Total Album';

// Text
$_['text_view']     = 'Se mere...';