<?php
// Heading
$_['heading_title']    = 'Backup & amp; Gendan';

// Text
$_['text_success']     = 'Succes: Du har importeret din database med succes!';

// Entry
$_['entry_import']     = 'Importere';
$_['entry_export']     = 'Eksport';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Backup & amp; Gendan!';
$_['error_export']     = 'Advarsel: Du skal vælge mindst en tabel til eksport!';
$_['error_empty']      = 'Advarsel: Filen du uploadede var tom!';