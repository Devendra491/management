<?php
// Heading
$_['heading_title']    = 'Kategori';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret kategori modul!';
$_['text_edit']        = 'Rediger kategori modul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre kategori modul!';