<?php
// Heading
$_['heading_title'] = 'Total Galleri';

// Text
$_['text_view']     = 'Se mere...';