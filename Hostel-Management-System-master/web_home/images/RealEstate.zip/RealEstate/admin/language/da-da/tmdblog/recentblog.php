<?php
// Heading
$_['heading_title']      = 'Seneste blogs';

// Column
$_['column_totalcoment'] = 'Samlet kommentar';
$_['column_sr_no']  	 = 'Blog Id';
$_['column_post']  		 = 'Blog';
$_['column_author']      = 'Kunde';
$_['column_status']      = 'Status';
$_['column_action']      = 'Handling';

