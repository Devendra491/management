<?php
// Heading
$_['heading_title']    = 'TMD Kategori Søgning';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret kategorisøgningsmodulet!';
$_['text_edit']        = 'Rediger Category Search Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre kategori søgning modul!';