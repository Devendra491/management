<?php
// Heading
$_['heading_title'] = '<b> I alt Blogs</b>';

// Text
$_['text_view']     = 'Se mere...';