<?php
// Heading
$_['heading_title']      = 'Seneste galleri';

// Column
$_['column_galleryid']   = 'Galleri-id';
$_['column_galleryname'] = 'Galleri navn';
$_['column_totalalbum']  = 'Total Album';
$_['column_status']      = 'Status';
$_['column_action']      = 'Handling';

