<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']	   = 'Succes: Du har ændret Google Analytics!';
$_['text_signup']      = 'Log ind på din <a href="http://www.google.com/analytics/" mål="_blank"><u>Google Analytics</u></a> konto og efter at have oprettet din webprofil, kopier og indsæt analysekoden i dette felt.';
$_['text_default']     = 'Standard';

// Entry
$_['entry_code']       = 'Google Analytics-kode';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Google Analytics!';
$_['error_code']	   = 'Kode kræves!';
