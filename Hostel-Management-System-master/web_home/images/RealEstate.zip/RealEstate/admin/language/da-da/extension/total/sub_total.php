<?php
// Heading
$_['heading_title']    = 'Sub-Total';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret summen i alt!';
$_['text_edit']        = 'Rediger Subtotal Total';

// Entry
$_['entry_status']     = 'status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre subtotals samlede!';