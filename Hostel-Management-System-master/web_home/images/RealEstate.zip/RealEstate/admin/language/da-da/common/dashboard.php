<?php
// Heading
$_['heading_title'] = 'instrumentbræt';

// Error
$_['error_install'] = 'Advarsel: Installer mappe eksisterer stadig og bør slettes af sikkerhedsmæssige årsager!';