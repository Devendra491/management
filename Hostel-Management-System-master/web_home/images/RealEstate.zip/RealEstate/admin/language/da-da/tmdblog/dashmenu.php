<?php
$_['text_dash']                     = 'instrumentbræt';
$_['text_blog']                    = 'Blogs';
$_['text_cate']                   = 'Kategori';
$_['text_comm']                    = 'Kommentar';
$_['text_sett']                    = 'Indstillinger';
$_['text_addmodule']                    = 'Tilføj modul';
