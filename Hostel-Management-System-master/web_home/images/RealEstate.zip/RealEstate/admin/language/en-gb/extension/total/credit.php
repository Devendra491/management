<?php
// Heading
$_['heading_title']    = 'Website Credit';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret butikken Website Total!';
$_['text_edit']        = 'Rediger Store Website Total';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Website Credit Total!';