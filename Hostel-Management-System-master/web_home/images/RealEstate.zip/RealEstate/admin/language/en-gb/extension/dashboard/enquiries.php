<?php

// Heading

$_['heading_title']    = 'Enquiries';



// Error

$_['error_permission'] = 'Warning: You do not have permission to modify dashboard listing!';